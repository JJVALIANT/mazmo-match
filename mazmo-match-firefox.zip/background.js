/*
 * Segundo plano: lee las respuestas JSON de api.mazmo.net con
 * webRequest.filterResponseData, sin depender de que la página cargue antes
 * o después de la extensión ni de su política de seguridad (CSP). Extrae los
 * usuarios (id, username, avatares) y los vínculos slug/id -> usuarios, y se
 * los envía al content script de esa pestaña.
 */
'use strict';

const API_HOST = 'api.mazmo.net';
const MAX_BYTES = 3 * 1024 * 1024;
const MAX_DEPTH = 12;
const MAX_USERS = 5000;
// Ids numéricos de usuarios que un objeto referencia sin traer el usuario completo
// (p. ej. participantes de un chat: [123, 456]). La propia página los resuelve
// después con GET /users?ids=..., y esa respuesta llena el diccionario id -> usuario.
const USERISH = /user|member|particip|author|owner|sender|peer|contact|recipient|friend/i;
const NOT_ID = /count|total|num|size|length|unread|time|date|At$/;
function gatherIds(node, out, depth, userish) {
  if (!node || typeof node !== 'object' || depth > 5 || out.size >= 30) return;
  if (Array.isArray(node)) {
    for (const item of node) {
      if (userish && Number.isInteger(item)) out.add(item);
      else gatherIds(item, out, depth + 1, userish);
    }
    return;
  }
  if (userish && Number.isInteger(node.id)) out.add(node.id);
  for (const k of Object.keys(node)) {
    if (NOT_ID.test(k)) continue;
    const v = node[k];
    if (v && typeof v === 'object') gatherIds(v, out, depth + 1, userish || USERISH.test(k));
    else if (Number.isInteger(v) && USERISH.test(k)) out.add(v);
  }
}

const HEX24 = /^[0-9a-f]{24}$/i;

function collectUrls(value, out, depth) {
  if (out.length >= 16 || depth > 3) return;
  if (typeof value === 'string') {
    if (value.length <= 500 && /^(https?:)?\/\/|^\//.test(value)) out.push(value);
    return;
  }
  if (value && typeof value === 'object') {
    for (const key of Object.keys(value)) collectUrls(value[key], out, depth + 1);
  }
}

function extractUsers(node, out, depth) {
  if (!node || typeof node !== 'object' || depth > MAX_DEPTH || out.size >= MAX_USERS) return;
  if (Array.isArray(node)) {
    for (const item of node) extractUsers(item, out, depth + 1);
    return;
  }
  const username = node.username;
  if (typeof username === 'string' && username.length > 0 && username.length <= 64) {
    const avatars = [];
    collectUrls(node.avatar, avatars, 0);
    out.set(username, {
      id: Number.isInteger(node.id) ? node.id : null,
      fullId: typeof node.fullId === 'string' ? node.fullId : null,
      username,
      avatars,
      displayname: typeof node.displayname === 'string' ? node.displayname.slice(0, 100) : null
    });
  }
  for (const key of Object.keys(node)) {
    const value = node[key];
    if (value && typeof value === 'object') extractUsers(value, out, depth + 1);
  }
}

function gatherUsers(node, out, depth) {
  if (!node || typeof node !== 'object' || depth > 5 || out.size >= 30) return;
  if (Array.isArray(node)) {
    for (const item of node) gatherUsers(item, out, depth + 1);
    return;
  }
  if (typeof node.username === 'string' && node.username && node.username.length <= 64) {
    out.set(node.username, typeof node.displayname === 'string' ? node.displayname.slice(0, 100) : null);
  }
  for (const key of Object.keys(node)) {
    const v = node[key];
    if (v && typeof v === 'object') gatherUsers(v, out, depth + 1);
  }
}

function extractBindings(node, out, depth) {
  if (!node || typeof node !== 'object' || depth > MAX_DEPTH || out.length >= 3000) return;
  if (Array.isArray(node)) {
    for (const item of node) extractBindings(item, out, depth + 1);
    return;
  }
  const key = typeof node.slug === 'string' && node.slug
    ? node.slug
    : (typeof node.id === 'string' && HEX24.test(node.id) ? node.id : null);
  if (key && key.length <= 200) {
    const users = new Map();
    gatherUsers(node, users, 0);
    const ids = new Set();
    gatherIds(node, ids, 0, false);
    if (users.size > 0 || ids.size > 0) {
      out.push({ key, users: [...users].map(([username, displayname]) => ({ username, displayname })), ids: [...ids] });
    }
  }
  for (const k of Object.keys(node)) {
    const v = node[k];
    if (v && typeof v === 'object') extractBindings(v, out, depth + 1);
  }
}

const stats = { solicitudes: 0, sinTab: 0, sinCuerpo: 0, noJson: 0, errores: 0, parseadas: 0, enviadas: 0, primerosBytes: null };

// Las respuestas pueden llegar sin pestaña asociada (p. ej. si las hace un service worker):
// en ese caso se envían a todas las pestañas de mazmo.net.
async function targetTabs(tabId) {
  if (tabId >= 0) return [tabId];
  stats.sinTab++;
  try {
    const tabs = await browser.tabs.query({ url: 'https://mazmo.net/*' });
    return tabs.map((t) => t.id);
  } catch (e) {
    return [];
  }
}

async function broadcast(tabId, message) {
  for (const id of await targetTabs(tabId)) send(id, message);
}

function sendStats() {
  browser.tabs.query({ url: 'https://mazmo.net/*' }).then((tabs) => {
    for (const t of tabs) send(t.id, { type: 'MAZMO_MATCH_BG_STATS', stats }, 3);
  }).catch(() => {});
}
setInterval(sendStats, 10000);

function send(tabId, message, attempt = 0) {
  browser.tabs.sendMessage(tabId, message).catch(() => {
    // El content script puede no estar listo todavía en una carga muy temprana.
    if (attempt < 3) setTimeout(() => send(tabId, message, attempt + 1), 300 * (attempt + 1));
  });
}

async function decodeBody(bytes) {
  // Por si el filtro entregara el cuerpo todavía comprimido (gzip).
  if (bytes.length > 2 && bytes[0] === 0x1f && bytes[1] === 0x8b && typeof DecompressionStream === 'function') {
    const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
    return new Response(stream).text();
  }
  return new TextDecoder('utf-8').decode(bytes);
}

async function handleBody(tabId, bytes, url) {
  let text;
  try { text = await decodeBody(bytes); } catch (e) { console.debug('[Mazmo Match bg] no se pudo decodificar', url, e); return; }
  const first = text.trimStart()[0];
  if (first !== '{' && first !== '[') {
    stats.noJson++;
    stats.primerosBytes = Array.from(bytes.slice(0, 4)).map((b) => b.toString(16).padStart(2, '0')).join(' ');
    return;
  }

  let json;
  try { json = JSON.parse(text); } catch (e) { stats.errores++; return; }
  stats.parseadas++;

  const users = new Map();
  extractUsers(json, users, 0);
  const bindings = [];
  extractBindings(json, bindings, 0);
  if (users.size === 0 && bindings.length === 0) return;

  console.debug(`[Mazmo Match bg] ${new URL(url).pathname}: usuarios=${users.size} vínculos=${bindings.length}`);
  stats.enviadas++;
  broadcast(tabId, { type: 'MAZMO_MATCH_DATA', users: [...users.values()], bindings });
}

browser.webRequest.onBeforeRequest.addListener(
  (details) => {
    if (details.method !== 'GET') return;
    stats.solicitudes++;
    let pathname;
    try { pathname = new URL(details.url).pathname; } catch (e) { return; }
    if (/\/checklist\/?$/.test(pathname)) return; // los pide la propia extensión

    let filter;
    try { filter = browser.webRequest.filterResponseData(details.requestId); } catch (e) { return; }

    const chunks = [];
    let size = 0;
    let overflow = false;

    filter.ondata = (event) => {
      // Copiar ANTES de escribir: write() podría invalidar el buffer original.
      let copy = null;
      if (!overflow) {
        size += event.data.byteLength;
        if (size > MAX_BYTES) { overflow = true; chunks.length = 0; }
        else copy = new Uint8Array(event.data.slice(0));
      }
      filter.write(event.data); // la respuesta pasa intacta a la página
      if (copy) chunks.push(copy);
    };

    filter.onstop = () => {
      try { filter.close(); } catch (e) { /* ya cerrado */ }
      if (overflow || chunks.length === 0) { stats.sinCuerpo++; return; }
      const all = new Uint8Array(size);
      let offset = 0;
      for (const c of chunks) { all.set(c, offset); offset += c.byteLength; }
      handleBody(details.tabId, all, details.url);
    };

    filter.onerror = () => { try { filter.disconnect(); } catch (e) {} };
  },
  { urls: ['https://' + API_HOST + '/*'], types: ['xmlhttprequest'] },
  ['blocking']
);

console.info('[Mazmo Match bg] segundo plano listo');
