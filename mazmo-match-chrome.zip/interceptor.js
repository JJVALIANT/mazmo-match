/*
 * Interceptor (corre en el contexto de la página).
 * Observa respuestas JSON de api.mazmo.net y avisa al content script qué
 * usuarios aparecieron, identificados SOLO por { id, fullId, username }.
 * Los displaynames se descartan a propósito: no son identificadores fiables.
 */
(function () {
  'use strict';

  if (window.__mazmoMatchInterceptor) return;
  window.__mazmoMatchInterceptor = true;

  const API_HOST = 'api.mazmo.net';
  const MAX_DEPTH = 12;
  const MAX_USERS = 5000;
  const MSG_SOURCE = 'MAZMO_MATCH_INTERCEPTOR';

  function isApiUrl(raw) {
    try {
      return new URL(String(raw), location.href).hostname === API_HOST;
    } catch (e) {
      return false;
    }
  }

  function isJsonType(contentType) {
    return typeof contentType === 'string' && contentType.toLowerCase().includes('json');
  }

  // URLs de avatar de un usuario (todas las variantes de tamaño/formato).
  // Sirven para reconocer su <img> en listas que no tienen enlace ni handle.
  function collectUrls(value, out, depth) {
    if (out.length >= 16 || depth > 3) return;
    if (typeof value === 'string') {
      if (value.length <= 500 && /^(https?:)?\/\/|^\//.test(value)) out.push(value);
      return;
    }
    if (value && typeof value === 'object') {
      for (const key of Object.keys(value)) collectUrls(value[key], out, depth + 1);
    }
  }

  // Recorre el JSON y junta todo objeto que tenga `username` string.
  // Sirve tanto para arrays de usuarios como para mapas indexados por id
  // (p. ej. GET /users?ids=...).
  function extractUsers(node, out, depth) {
    if (!node || typeof node !== 'object' || depth > MAX_DEPTH || out.size >= MAX_USERS) return;

    if (Array.isArray(node)) {
      for (const item of node) extractUsers(item, out, depth + 1);
      return;
    }

    const username = node.username;
    if (typeof username === 'string' && username.length > 0 && username.length <= 64) {
      const avatars = [];
      collectUrls(node.avatar, avatars, 0);
      out.set(username, {
        id: Number.isInteger(node.id) ? node.id : null,
        fullId: typeof node.fullId === 'string' ? node.fullId : null,
        username,
        avatars,
        displayname: typeof node.displayname === 'string' ? node.displayname.slice(0, 100) : null
      });
    }

    for (const key of Object.keys(node)) {
      const value = node[key];
      if (value && typeof value === 'object') extractUsers(value, out, depth + 1);
    }
  }

  // Usuarios (username + displayname) contenidos en un objeto, p. ej. un tema
  // con su autor y su último respondedor.
  function gatherUsers(node, out, depth) {
    if (!node || typeof node !== 'object' || depth > 5 || out.size >= 30) return;
    if (Array.isArray(node)) {
      for (const item of node) gatherUsers(item, out, depth + 1);
      return;
    }
    if (typeof node.username === 'string' && node.username && node.username.length <= 64) {
      out.set(node.username, typeof node.displayname === 'string' ? node.displayname.slice(0, 100) : null);
    }
    for (const key of Object.keys(node)) {
      const v = node[key];
      if (v && typeof v === 'object') gatherUsers(v, out, depth + 1);
    }
  }

  // Un objeto con `slug` (temas) o con un id de 24 hex (chats, canales) es
  // algo que la página enlaza por URL. Se guarda a qué usuarios menciona, para
  // atar cada fila de la página a un conjunto cerrado de candidatos.
  // Ids numéricos de usuarios que un objeto referencia sin traer el usuario completo
  // (p. ej. participantes de un chat: [123, 456]). La propia página los resuelve
  // después con GET /users?ids=..., y esa respuesta llena el diccionario id -> usuario.
  const USERISH = /user|member|particip|author|owner|sender|peer|contact|recipient|friend/i;
  const NOT_ID = /count|total|num|size|length|unread|time|date|At$/;
  function gatherIds(node, out, depth, userish) {
    if (!node || typeof node !== 'object' || depth > 5 || out.size >= 30) return;
    if (Array.isArray(node)) {
      for (const item of node) {
        if (userish && Number.isInteger(item)) out.add(item);
        else gatherIds(item, out, depth + 1, userish);
      }
      return;
    }
    if (userish && Number.isInteger(node.id)) out.add(node.id);
    for (const k of Object.keys(node)) {
      if (NOT_ID.test(k)) continue;
      const v = node[k];
      if (v && typeof v === 'object') gatherIds(v, out, depth + 1, userish || USERISH.test(k));
      else if (Number.isInteger(v) && USERISH.test(k)) out.add(v);
    }
  }

  const HEX24 = /^[0-9a-f]{24}$/i;
  function extractBindings(node, out, depth) {
    if (!node || typeof node !== 'object' || depth > 12 || out.length >= 3000) return;
    if (Array.isArray(node)) {
      for (const item of node) extractBindings(item, out, depth + 1);
      return;
    }
    const key = typeof node.slug === 'string' && node.slug
      ? node.slug
      : (typeof node.id === 'string' && HEX24.test(node.id) ? node.id : null);
    if (key && key.length <= 200) {
      const users = new Map();
      gatherUsers(node, users, 0);
      const ids = new Set();
      gatherIds(node, ids, 0, false);
      if (users.size > 0 || ids.size > 0) {
        out.push({ key, users: [...users].map(([username, displayname]) => ({ username, displayname })), ids: [...ids] });
      }
    }
    for (const k of Object.keys(node)) {
      const v = node[k];
      if (v && typeof v === 'object') extractBindings(v, out, depth + 1);
    }
  }

  function publish(json) {
    try {
      const out = new Map();
      extractUsers(json, out, 0);
      const bindings = [];
      extractBindings(json, bindings, 0);
      if (out.size === 0 && bindings.length === 0) return;
      window.postMessage(
        { source: MSG_SOURCE, users: Array.from(out.values()), bindings },
        location.origin
      );
    } catch (e) {
      /* nunca romper la página */
    }
  }

  // ---- fetch ----
  try {
    const originalFetch = window.fetch;
    window.fetch = async function (...args) {
      const response = await originalFetch.apply(this, args);
      try {
        const req = args[0];
        const url = typeof req === 'string'
          ? req
          : (req instanceof URL ? req.href : (req && req.url));
        if (isApiUrl(url) && isJsonType(response.headers.get('content-type'))) {
          // clone() sincrónico, antes de devolver la respuesta a la página
          response.clone().json().then(publish).catch(() => {});
        }
      } catch (e) {}
      return response;
    };
  } catch (e) {
    console.warn('[Mazmo Match] No se pudo envolver fetch:', e);
  }

  // ---- XMLHttpRequest ----
  try {
    const xhrUrls = new WeakMap();
    const originalOpen = XMLHttpRequest.prototype.open;
    const originalSend = XMLHttpRequest.prototype.send;

    XMLHttpRequest.prototype.open = function (method, url, ...rest) {
      try { xhrUrls.set(this, String(url)); } catch (e) {}
      return originalOpen.call(this, method, url, ...rest);
    };

    XMLHttpRequest.prototype.send = function (...args) {
      this.addEventListener('load', () => {
        try {
          if (!isApiUrl(xhrUrls.get(this))) return;
          if (!isJsonType(this.getResponseHeader('content-type'))) return;
          if (this.responseType === 'json') publish(this.response);
          else if (this.responseType === '' || this.responseType === 'text') publish(JSON.parse(this.responseText));
        } catch (e) {}
      });
      return originalSend.apply(this, args);
    };
  } catch (e) {
    console.warn('[Mazmo Match] No se pudo envolver XHR:', e);
  }
})();
