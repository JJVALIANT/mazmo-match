'use strict';

// Firefox expone `browser`; Chrome/Edge, `chrome`.
const api = globalThis.browser ?? globalThis.chrome;

// Nombre, versión y descripción salen del manifest, así nunca quedan desactualizados.
const manifest = api.runtime.getManifest();
document.getElementById('name').textContent = manifest.name;
document.getElementById('version').textContent = `v${manifest.version}`;
document.getElementById('description').textContent = manifest.description;

// Opción: cargar las conversaciones (apagada por defecto). La lee content.js.
const optMessengers = document.getElementById('opt-messengers');
Promise.resolve(api.storage.local.get('fetchMessengers'))
  .then((v) => { optMessengers.checked = !!v && v.fetchMessengers === true; })
  .catch(() => {});
optMessengers.addEventListener('change', () => {
  api.storage.local.set({ fetchMessengers: optMessengers.checked });
});

// Chrome/Edge no permiten fijar el ícono en la barra por defecto: si no está fijado, se avisa.
if (api.action && typeof api.action.getUserSettings === 'function') {
  Promise.resolve(api.action.getUserSettings())
    .then((settings) => {
      if (settings && settings.isOnToolbar === false) {
        document.getElementById('pin-hint').hidden = false;
      }
    })
    .catch(() => { /* sin soporte: no se muestra el aviso */ });
}
