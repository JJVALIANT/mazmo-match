'use strict';

/* ======================================================================
 * Mazmo Match - content script
 *
 * Reglas de diseño:
 *  1. Identidad: un usuario se identifica SOLO por su username, tomado de un
 *     enlace de perfil (/@username) o, opcionalmente, de un id numérico
 *     resuelto vía GET /users?ids=. Nunca por displayname ni por texto suelto.
 *     Si no hay ancla inequívoca, no se pone badge.
 *  2. Demanda: se piden checklists solo de usuarios presentes en el DOM.
 *  3. Cortesía con la API: pocas peticiones en paralelo, backoff ante 429,
 *     caché persistente (solo el score, nunca el checklist crudo).
 * ====================================================================== */

const API_BASE = 'https://api.mazmo.net';

const INTEREST_WEIGHTS = { LOT: 3, SOME: 2, LITTLE: 1, NONE: 0 };

const CONFIG = {
  CONCURRENCY: 2,             // pedidos simultáneos (subir solo si el límite lo permite)
  SPACING_MS: 250,            // pausa entre tandas
  MAX_QUEUE: 300,             // tope de usuarios en espera
  STALE_AFTER_MS: 20000,      // si un usuario no se ve en el DOM por este tiempo, no se pide
  BACKOFF_START_MS: 2000,
  BACKOFF_MAX_MS: 60000,
  MAX_RETRIES: 3,             // reintentos por usuario ante errores transitorios
  TTL_OK_MS: 6 * 60 * 60 * 1000,
  TTL_NONE_MS: 60 * 60 * 1000,
  TTL_ERROR_MS: 60 * 1000,
  MAX_STORED: 5000,           // entradas máximas en storage.local
  FLUSH_DEBOUNCE_MS: 150,
  FULL_SCAN_EVERY_MS: 5000,   // red de seguridad por si se escapa alguna mutación

  // Pedir también los usuarios que aparecen en respuestas de red aunque no
  // estén en pantalla. Desactivado: es lo que dispara cientos de pedidos.
  PREFETCH_FROM_NETWORK: false,

  // Si en pantalla hay conversaciones (/chat/messengers/<id>) que la extensión no
  // conoce, pide GET /chat/messengers (como hace la propia página al cargar).
  // OJO: según la doc de la API, listar las conversaciones marca sus últimos
  // mensajes como "recibidos". Por eso está apagado por defecto; cada persona lo
  // activa desde la ventana del ícono (se guarda en storage.local como `fetchMessengers`).
  FETCH_MESSENGERS: false,

  // Ancla alternativa por id numérico. Si en el DOM existe un atributo que
  // contenga el id del usuario (p. ej. 'data-user-id'), ponelo acá. Verificalo
  // en DevTools antes de activarlo. null = desactivado.
  // Enlaces a un perfil cuyo texto es una acción y no un nombre (en minúsculas).
  // Si ves un badge pegado a un botón/enlace así, agregá su texto acá.
  SKIP_LINK_LABELS: ['ver perfil', 'ver más', 'ver mas', 'perfil', 'mensaje', 'enviar mensaje', 'seguir'],

  ID_ATTRIBUTE: null,
  ID_RESOLVE_CHUNK: 50,
  ID_RETRY_AFTER_MS: 60000
};

const BADGE_CLASS = 'mazmo-match-badge';
const SKIP_LABELS = new Set(CONFIG.SKIP_LINK_LABELS);
const LINK_SELECTOR = 'a[href*="/@"]';
const CARD_SELECTOR = 'article, li, [role="listitem"], [role="group"]';
const ID_SELECTOR = CONFIG.ID_ATTRIBUTE ? `[${CONFIG.ID_ATTRIBUTE}]` : null;
const USERNAME_RE = /^[^\s/?#@\\%]{1,64}$/;
// Para depurar sin editar archivos, en la consola de mazmo.net ejecutá:
//   localStorage.mazmoMatchDebug = '1'    y recargá la página.
const DEBUG = (() => {
  try { return localStorage.getItem('mazmoMatchDebug') === '1'; } catch (e) { return false; }
})();

const log = (...args) => { if (DEBUG) console.debug('[Mazmo Match]', ...args); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Firefox expone `browser`; Chrome/Edge, `chrome` (con promesas en Manifest V3).
const ext = globalThis.browser ?? globalThis.chrome;

/* ----------------------------------------------------------------------
 * Inyección del interceptor
 * -------------------------------------------------------------------- */
// Solo en Manifest V2 (Firefox): en Manifest V3 (Chrome) el interceptor ya corre como
// script de contenido en el mundo "MAIN" y se declara en el manifest.
try {
  if (ext.runtime.getManifest().manifest_version !== 2) throw new Error('mv3');
  const script = document.createElement('script');
  script.src = ext.runtime.getURL('interceptor.js');
  script.async = false;
  script.onload = () => script.remove();
  (document.head || document.documentElement).appendChild(script);
} catch (e) {
  if (e.message !== 'mv3') console.warn('[Mazmo Match] No se pudo inyectar el interceptor:', e);
}

/* ----------------------------------------------------------------------
 * Estado
 * -------------------------------------------------------------------- */
let epoch = 0;                 // se incrementa en cada (re)inicio de sesión
let ready = false;
let activeToken = null;
let myUsername = null;
let mySelections = null;
let ownerKey = null;

const cache = new Map();       // username -> { state, percentage, sharedPractices, exp }
const idToUsername = new Map();
const avatarToUser = new Map();    // URL de avatar normalizada -> Set de usernames
const fullIdToUsername = new Map(); // fullId (24 hex) -> username
const ownerStats = { agree: 0, disagree: 0 }; // ¿el prefijo hex del archivo de avatar es el fullId del dueño?
const avatarChoice = new WeakMap(); // img -> usuario elegido cuando la imagen es compartida
const noneLog = [];               // últimos usuarios sin checklist accesible (para diagnóstico)
const avatarKeyCache = new Map();
const displayNames = new Map();   // username -> displayname (solo para vetar coincidencias dudosas)
const bindings = new Map();        // slug/id de la URL -> Map(username -> displayname|null)
const hrefSegCache = new Map();
const avatarSeen = new WeakMap();   // img -> última evaluación (para no repetir trabajo)
const boundProofs = new WeakMap(); // hoja de texto -> { anchor, key }
const idAttempted = new Map(); // id -> timestamp del último intento de resolución
const lastSeen = new Map();    // username -> última vez visto en el DOM
const pending = new Set();     // en cola o en vuelo
const retries = new Map();
const badgeTargets = new WeakMap();
const badgeProofs = new WeakMap();   // badge -> elemento que prueba la identidad

let queue = [];
let inFlight = new Set();      // usuarios del lote que se está pidiendo ahora
let lastError = null;
let healed = 0;               // usuarios 'pendientes' que no estaban en ninguna parte y se liberaron
let bgStats = null;           // contadores que informa background.js
let workerRunning = false;
let pausedUntil = 0;
let backoffMs = CONFIG.BACKOFF_START_MS;

/* ----------------------------------------------------------------------
 * Utilidades de sesión / red
 * -------------------------------------------------------------------- */
function getToken() {
  try { return localStorage.getItem('sessionToken'); } catch (e) { return null; }
}

function authHeaders() {
  return { Authorization: `Bearer ${getToken()}`, Accept: 'application/json' };
}

function isValidUsername(u) {
  return typeof u === 'string' && USERNAME_RE.test(u);
}

/* ----------------------------------------------------------------------
 * Compatibilidad
 * -------------------------------------------------------------------- */
function flattenChecklist(categories) {
  const map = new Map();
  if (!Array.isArray(categories)) return map;

  for (const cat of categories) {
    if (!cat || !Array.isArray(cat.selections)) continue;
    for (const sel of cat.selections) {
      if (!sel || !sel.item || !sel.item.id) continue;
      map.set(sel.item.id, {
        weight: INTEREST_WEIGHTS[sel.interest] ?? 0,
        relatesTo: sel.item.relatesTo || sel.item.id,
        name: sel.item.name
      });
    }
  }
  return map;
}

// Nota: el score es asimétrico (mide cuánto cubre la lista del otro la tuya).
function calculateCompatibility(theirCategories) {
  const theirMap = flattenChecklist(theirCategories);
  if (theirMap.size === 0 || !mySelections || mySelections.size === 0) return null;

  let earned = 0;
  let maxPossible = 0;
  let shared = 0;

  for (const [myItemId, mine] of mySelections) {
    if (mine.weight <= 0) continue;
    const theirs = theirMap.get(mine.relatesTo || myItemId);
    maxPossible += mine.weight * 3;
    if (theirs && theirs.weight > 0) {
      earned += mine.weight * theirs.weight;
      shared++;
    }
  }

  if (maxPossible === 0) return null;
  return { percentage: Math.round((earned / maxPossible) * 100), sharedPractices: shared };
}

function hashSelections(map) {
  const text = [...map].map(([id, d]) => `${id}:${d.weight}:${d.relatesTo}`).sort().join('|');
  let h = 5381;
  for (let i = 0; i < text.length; i++) h = ((h << 5) + h + text.charCodeAt(i)) | 0;
  return String(h);
}

/* ----------------------------------------------------------------------
 * Caché (memoria + storage.local). Solo se guarda el resultado, nunca el
 * checklist del otro usuario.
 * -------------------------------------------------------------------- */
function peek(username) {
  const e = cache.get(username);
  if (!e) return null;
  if (e.exp <= Date.now()) { cache.delete(username); return null; }
  return e;
}

function store(username, state, result) {
  const ttl = state === 'ok' ? CONFIG.TTL_OK_MS
    : state === 'none' ? CONFIG.TTL_NONE_MS
    : CONFIG.TTL_ERROR_MS;
  cache.set(username, {
    state,
    percentage: result.percentage,
    sharedPractices: result.sharedPractices,
    exp: Date.now() + ttl
  });
  if (state !== 'error') scheduleSave();
}

async function loadStoredCache() {
  cache.clear();
  try {
    const s = await ext.storage.local.get(['matchCache', 'matchOwner']);
    // Si cambió el usuario o su checklist, los scores guardados ya no valen.
    if (s.matchOwner !== ownerKey || !s.matchCache) return;
    const now = Date.now();
    for (const [u, e] of Object.entries(s.matchCache)) {
      if (e && e.exp > now) cache.set(u, e);
    }
  } catch (e) {
    log('No se pudo leer el caché:', e);
  }
}

let saveTimer = null;
function scheduleSave() {
  if (saveTimer) return;
  saveTimer = setTimeout(async () => {
    saveTimer = null;
    if (!ownerKey) return;
    const now = Date.now();
    const out = {};
    let n = 0;
    for (const [u, e] of cache) {
      if (e.state === 'error' || e.exp <= now) continue;
      out[u] = e;
      if (++n >= CONFIG.MAX_STORED) break;
    }
    try {
      await ext.storage.local.set({ matchCache: out, matchOwner: ownerKey });
    } catch (e) {
      log('No se pudo guardar el caché:', e);
    }
  }, 2000);
}

/* ----------------------------------------------------------------------
 * Cola de pedidos de checklists
 * -------------------------------------------------------------------- */
function inViewport(el) {
  try {
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0 && r.bottom > 0 && r.top < window.innerHeight &&
      r.right > 0 && r.left < window.innerWidth;
  } catch (e) {
    return false;
  }
}

// `el` (opcional): elemento donde se mostraría el badge. Si está a la vista, el
// usuario pasa al frente de la cola, así lo que mirás se resuelve primero.
function request(username, el) {
  const hit = peek(username);
  if (hit) return hit;

  const visible = !!el && inViewport(el);
  if (!pending.has(username)) {
    if (queue.length < CONFIG.MAX_QUEUE) {
      pending.add(username);
      if (visible) queue.unshift(username); else queue.push(username);
      // microtarea: deja que el escaneo termine de encolar antes de armar el primer lote
      queueMicrotask(startWorker);
    }
  } else if (visible) {
    const i = queue.indexOf(username);
    if (i > 0) { queue.splice(i, 1); queue.unshift(username); }
  }
  return null;
}

function finish(username) {
  pending.delete(username);
  retries.delete(username);
}

function retryLater(username) {
  const n = (retries.get(username) || 0) + 1;
  if (n > CONFIG.MAX_RETRIES) {
    store(username, 'error', {});
    finish(username);
    return;
  }
  retries.set(username, n);
  queue.push(username);
}

function takeBatch() {
  const batch = [];
  const now = Date.now();
  while (batch.length < CONFIG.CONCURRENCY && queue.length) {
    const u = queue.shift();
    if (now - (lastSeen.get(u) || 0) > CONFIG.STALE_AFTER_MS) {
      pending.delete(u); // ya no está en pantalla; se re-pedirá si vuelve
      continue;
    }
    batch.push(u);
  }
  return batch;
}

async function errorCode(res) {
  try { return (await res.json()).code || null; } catch (e) { return null; }
}

function parseRetryAfter(res) {
  const v = Number(res.headers.get('retry-after'));
  return Number.isFinite(v) && v > 0 ? Math.min(v * 1000, CONFIG.BACKOFF_MAX_MS) : null;
}

// Códigos que afectan a TODA la cuenta (no a un usuario puntual)
const GLOBAL_403_CODES = new Set(['EMAIL_VERIFICATION_REQUIRED']);

async function fetchChecklist(username) {
  try {
    const res = await fetch(`${API_BASE}/users/${encodeURIComponent(username)}/checklist`, {
      headers: authHeaders(),
      // sin tiempo máximo, una petición colgada bloquearía toda la cola
      ...(typeof AbortSignal !== 'undefined' && AbortSignal.timeout ? { signal: AbortSignal.timeout(15000) } : {})
    });
    if (res.ok) return { outcome: 'ok', data: await res.json() };
    if (res.status === 429) return { outcome: 'rate', retryAfterMs: parseRetryAfter(res) };
    if (res.status === 401) return { outcome: 'auth' };

    const code = await errorCode(res);
    log(`checklist de ${username}: HTTP ${res.status} ${code || ''}`);

    if (res.status >= 500) return { outcome: 'retry' };
    if (res.status === 403 && GLOBAL_403_CODES.has(code)) return { outcome: 'fatal', code };
    // Bloqueo, checklist privado, 404 y demás 4xx: es asunto de ese usuario -> definitivo
    return { outcome: 'none', status: res.status, code };
  } catch (e) {
    log(`checklist de ${username}: error de red`, e);
    return { outcome: 'retry' };
  }
}

function handleResults(batch, results) {
  let rate = null;
  let auth = false;
  let fatal = null;

  batch.forEach((username, i) => {
    const r = results[i];
    outcomeCounts[r.outcome] = (outcomeCounts[r.outcome] || 0) + 1;
    switch (r.outcome) {
      case 'ok': {
        const score = calculateCompatibility(r.data);
        log(`${username}: ${score ? score.percentage + '%' : 'sin datos comparables'}`);
        store(username, score ? 'ok' : 'none', score || {});
        finish(username);
        break;
      }
      case 'none':
        store(username, 'none', {});
        noneLog.push(`${username}:${r.status || '-'}${r.code ? ':' + r.code : ''}`);
        if (noneLog.length > 40) noneLog.shift();
        finish(username);
        break;
      case 'rate':
        rate = r;
        queue.unshift(username);
        break;
      case 'auth':
        auth = true;
        queue.unshift(username);
        break;
      case 'fatal':
        fatal = r;
        queue.unshift(username);
        break;
      default:
        retryLater(username);
    }
  });

  const now = Date.now();
  if (rate) {
    pausedUntil = now + (rate.retryAfterMs ?? backoffMs);
    backoffMs = Math.min(backoffMs * 2, CONFIG.BACKOFF_MAX_MS);
    log('429: pausa hasta', new Date(pausedUntil).toISOString());
  } else if (auth) {
    pausedUntil = now + 30000; // el watcher de sesión reiniciará si cambió el token
  } else if (fatal) {
    pausedUntil = now + 5 * 60 * 1000;
    console.warn('[Mazmo Match] La API rechazó los pedidos:', fatal.code);
  } else {
    backoffMs = CONFIG.BACKOFF_START_MS;
  }
}

async function startWorker() {
  if (workerRunning || !ready) return;
  workerRunning = true;
  const myEpoch = epoch;
  try {
    while (queue.length && ready && myEpoch === epoch) {
      const wait = pausedUntil - Date.now();
      if (wait > 0) { await sleep(wait); continue; }

      const batch = takeBatch();
      if (batch.length === 0) break;
      inFlight = new Set(batch);

      try {
        const results = await Promise.all(batch.map(fetchChecklist));
        if (myEpoch !== epoch) return;
        handleResults(batch, results);
      } catch (e) {
        // Un error acá no debe dejar usuarios colgados para siempre.
        lastError = String((e && e.stack) || e).slice(0, 400);
        console.error('[Mazmo Match] Error en la cola de checklists:', e);
        if (myEpoch === epoch) {
          for (const u of batch) {
            if (pending.has(u) && !queue.includes(u)) { store(u, 'error', {}); finish(u); }
          }
        }
      }
      inFlight = new Set();
      scheduleFlush(true);

      if (queue.length) await sleep(CONFIG.SPACING_MS);
    }
  } finally {
    if (myEpoch === epoch) workerRunning = false;
  }
}

/* ----------------------------------------------------------------------
 * Resolución opcional de ids numéricos -> username (GET /users?ids=)
 * Solo se usa si CONFIG.ID_ATTRIBUTE está configurado.
 * -------------------------------------------------------------------- */
function collectAvatarUrls(value, out, depth) {
  if (out.length >= 16 || depth > 3) return;
  if (typeof value === 'string') {
    if (value.length <= 500 && /^(https?:)?\/\/|^\//.test(value)) out.push(value);
    return;
  }
  if (value && typeof value === 'object') {
    for (const k of Object.keys(value)) collectAvatarUrls(value[k], out, depth + 1);
  }
}

const idQueue = new Set();
let idTimer = null;

function wantId(id) {
  const last = idAttempted.get(id) || 0;
  if (Date.now() - last < CONFIG.ID_RETRY_AFTER_MS) return;
  idAttempted.set(id, Date.now());
  idQueue.add(id);
  if (!idTimer) idTimer = setTimeout(resolveIds, 100);
}

async function resolveIds() {
  idTimer = null;
  const ids = [...idQueue];
  idQueue.clear();
  const myEpoch = epoch;

  for (let i = 0; i < ids.length; i += CONFIG.ID_RESOLVE_CHUNK) {
    if (Date.now() < pausedUntil) await sleep(pausedUntil - Date.now());
    const chunk = ids.slice(i, i + CONFIG.ID_RESOLVE_CHUNK);
    try {
      // Formato de `ids` no especificado en la doc: se asume lista separada por comas.
      const res = await fetch(`${API_BASE}/users?ids=${chunk.join(',')}`, { headers: authHeaders() });
      if (res.status === 429) { pausedUntil = Date.now() + backoffMs; break; }
      if (!res.ok) continue;
      const body = await res.json();
      for (const u of Object.values(body || {})) {
        // Usuarios suspendidos/bloqueados vienen "en blanco": se ignoran.
        if (u && Number.isInteger(u.id) && isValidUsername(u.username)) {
          idToUsername.set(u.id, u.username);
          if (typeof u.displayname === 'string' && u.displayname) displayNames.set(u.username, u.displayname);
          const urls = [];
          collectAvatarUrls(u.avatar, urls, 0);
          for (const url of urls) learnAvatar(url, u.username);
        }
      }
    } catch (e) {
      log('Error resolviendo ids:', e);
    }
    if (myEpoch !== epoch) return;
  }
  scheduleFlush(true);
}

/* ----------------------------------------------------------------------
 * Mensajes del interceptor
 * -------------------------------------------------------------------- */
const outcomeCounts = {};
const feedStats = { page: 0, background: 0, api: 0, users: 0, bindings: 0 };

// Datos de red: llegan del interceptor de la página y, sobre todo, del script
// de segundo plano (background.js), que ve las respuestas aunque la página
// haya cargado antes que la extensión.
function ingest(data, via) {
  let learned = false;
  const users = Array.isArray(data.users) ? data.users.slice(0, 5000) : [];
  for (const u of users) {
    if (!u || !isValidUsername(u.username)) continue;
    const fullId = typeof u.fullId === 'string' && /^[0-9a-f]{24}$/i.test(u.fullId) ? u.fullId.toLowerCase() : null;
    if (fullId && fullIdToUsername.get(fullId) !== u.username) {
      fullIdToUsername.set(fullId, u.username);
      learned = true;
    }
    if (Array.isArray(u.avatars)) {
      // (no usar .some(): cortaría en la primera y no aprendería las demás variantes)
      for (const url of u.avatars.slice(0, 16)) {
        if (learnAvatar(url, u.username)) learned = true;
        const hex = ownerHexOf(url);
        if (hex && fullId) { if (hex === fullId) ownerStats.agree++; else ownerStats.disagree++; }
      }
    }
    if (typeof u.displayname === 'string' && u.displayname) displayNames.set(u.username, u.displayname);
    if (Number.isInteger(u.id) && idToUsername.get(u.id) !== u.username) {
      idToUsername.set(u.id, u.username);
      learned = true;
    }
    if (CONFIG.PREFETCH_FROM_NETWORK && ready && u.username !== myUsername) {
      lastSeen.set(u.username, Date.now());
      request(u.username);
    }
  }
  const binds = Array.isArray(data.bindings) ? data.bindings.slice(0, 3000) : [];
  for (const b of binds) {
    if (learnBinding(b)) learned = true;
  }

  feedStats[via] += 1;
  feedStats.users += users.length;
  feedStats.bindings += binds.length;
  if (DEBUG) log(`datos recibidos (${via}): usuarios=${users.length} vínculos=${binds.length}`);
  if (learned && ready) scheduleFlush(true);
}

window.addEventListener('message', (event) => {
  if (event.source !== window || event.origin !== location.origin) return;
  const data = event.data;
  if (!data || data.source !== 'MAZMO_MATCH_INTERCEPTOR') return;
  ingest(data, 'page');
});

ext.runtime.onMessage.addListener((msg) => {
  if (!msg) return;
  if (msg.type === 'MAZMO_MATCH_DATA') ingest(msg, 'background');
  else if (msg.type === 'MAZMO_MATCH_BG_STATS') bgStats = msg.stats;
});

/* ----------------------------------------------------------------------
 * Identificación de usuarios en el DOM
 * -------------------------------------------------------------------- */
function usernameFromLink(a) {
  const href = a.getAttribute('href');
  if (!href) return null;
  let url;
  try { url = new URL(href, location.origin); } catch (e) { return null; }
  if (url.origin !== location.origin) return null;
  const m = url.pathname.match(/^\/@([^/]+)\/?$/);
  if (!m) return null;
  let name;
  try { name = decodeURIComponent(m[1]); } catch (e) { return null; }
  return isValidUsername(name) ? name : null;
}

// Si dentro de un contenedor hay exactamente un usuario distinto, es inequívoco.
function uniqueUserIn(container) {
  const names = new Set();
  for (const a of container.querySelectorAll(LINK_SELECTOR)) {
    const u = usernameFromLink(a);
    if (u) names.add(u);
  }
  return names.size === 1 ? [...names][0] : null;
}

// Un elemento hoja cuyo texto completo es exactamente "@username" identifica
// a ese usuario sin ambigüedad (cabecera de perfil, listas "Siguiendo", etc.).
const HANDLE_TEXT_RE = /^\s*@([^\s/?#@\\%]{1,64})\s*$/;

function usernameFromHandleText(el) {
  if (!el) return null;
  const m = HANDLE_TEXT_RE.exec(el.textContent);
  return m ? m[1] : null;
}

// En una página de perfil (/@username[/...]) la identidad la da la propia URL.
function usernameFromLocation() {
  const m = location.pathname.match(/^\/@([^/]+)(?:\/|$)/);
  if (!m) return null;
  try {
    const name = decodeURIComponent(m[1]);
    return isValidUsername(name) ? name : null;
  } catch (e) {
    return null;
  }
}

// Marca especial: "la prueba de identidad es la URL actual".
const ROUTE_PROOF = document.documentElement;

// Usuario que prueba la "ancla" de un badge (enlace, atributo de id o handle).
function userOfProof(el) {
  if (el === ROUTE_PROOF) return usernameFromLocation();
  if (el.tagName === 'IMG') {
    const c = usersForAvatar(el);
    return c.length === 1 ? c[0] : (c.length > 1 ? pickByRowName(el, c) : null);
  }
  if (boundProofs.has(el)) return userOfBoundLeaf(el);
  if (el.matches(LINK_SELECTOR)) return usernameFromLink(el);
  if (ID_SELECTOR && el.matches(ID_SELECTOR)) {
    return idToUsername.get(Number(el.getAttribute(CONFIG.ID_ATTRIBUTE))) || null;
  }
  return usernameFromHandleText(el);
}

/* ----------------------------------------------------------------------
 * Colocación de badges (la heurística solo decide DÓNDE; el QUIÉN ya está
 * resuelto por el enlace/id)
 * -------------------------------------------------------------------- */
function isNameText(text) {
  return text.length > 0 && text.length <= 60 && !text.startsWith('@') && !text.includes('%');
}

// Hoja de texto: no tiene elementos hijos, salvo nuestros propios badges.
function isTextLeaf(el) {
  for (const c of el.children) {
    // los emojis suelen ser <img>: un nombre con emoji sigue siendo un nombre
    if (!c.classList.contains(BADGE_CLASS) && !(c.tagName === 'IMG' && c.children.length === 0)) return false;
  }
  return true;
}

// Texto propio de un elemento, sin contar los badges que le pusimos.
function ownText(el) {
  let t = '';
  for (const n of el.childNodes) {
    if (n.nodeType === 3) t += n.nodeValue;
    else if (n.nodeType === 1 && !n.classList.contains(BADGE_CLASS)) t += n.textContent;
  }
  return t;
}

const normName = (t) => t.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '');

// Veto, no identificación: si se conoce el nombre de ese usuario, el texto de la
// fila tiene que ser compatible con él. Evita atribuir mal una fila cuando dos
// usuarios comparten la misma imagen de avatar (la imagen por defecto).
function nameCompatible(username, text) {
  const display = displayNames.get(username);
  if (!display) return true; // sin dato, no se puede vetar
  const t = normName(text);
  if (!t) return false;
  return [normName(username), normName(display)].filter(Boolean).some((c) => c.includes(t) || t.includes(c));
}

function findNameLeaf(root, accept) {
  for (const el of root.querySelectorAll('p, span, h1, h2, h3, h4, strong, b')) {
    if (!isTextLeaf(el)) continue;
    if (el.closest('.' + BADGE_CLASS)) continue;
    const text = ownText(el).trim();
    if (isNameText(text) && (!accept || accept(text))) return el;
  }
  return null;
}

// Sube desde el enlace hasta encontrar un contenedor con un nombre visible.
// Se detiene si el contenedor mezcla más de un usuario (sería ambiguo).
function nameLeafNear(link, username) {
  let el = link.parentElement;
  for (let i = 0; i < 5 && el && el !== document.body; i++) {
    if (uniqueUserIn(el) !== username) return null;
    const leaf = findNameLeaf(el);
    if (leaf) return leaf;
    el = el.parentElement;
  }
  return null;
}

function pickBadgeTarget(link, username) {
  const hasImg = !!link.querySelector('img');
  const label = link.textContent.trim();
  const hasText = label.length > 0 && !SKIP_LABELS.has(label.toLowerCase());

  if (!hasImg) return hasText ? link : null;

  // Enlace que envuelve avatar (y quizá el nombre)
  const inside = findNameLeaf(link);
  if (inside) return inside;
  if (hasText) return link;

  // Solo avatar: el nombre está fuera del enlace
  return nameLeafNear(link, username);
}

function hasBadgeFor(scope, username) {
  for (const b of scope.querySelectorAll('.' + BADGE_CLASS)) {
    if (b.dataset.user === username) return true;
  }
  return false;
}

function paint(badge, entry) {
  const text = `${entry.percentage}%`;
  if (badge.textContent !== text) badge.textContent = text;
  badge.title = `Compatibilidad: ${entry.percentage}% (${entry.sharedPractices} prácticas compatibles)`;
  badge.dataset.level = entry.percentage >= 70 ? 'high' : entry.percentage >= 40 ? 'mid' : 'low';
}

// `inside`: el badge va como último hijo del elemento (para textos de bloque,
// donde "después" lo mandaría a otra línea).
// mode: 'after' (hermano siguiente), 'in' (último hijo, para textos de bloque)
// o 'below' (debajo de un avatar, posicionado en absoluto).
function placeBadge(target, username, entry, proof, mode = 'after') {
  const hosted = mode !== 'after';
  const adjacent = hosted ? target.lastElementChild : target.nextElementSibling;

  if (adjacent && adjacent.classList.contains(BADGE_CLASS)) {
    if (adjacent.dataset.user === username) {
      paint(adjacent, entry);
      badgeTargets.set(adjacent, target);
      badgeProofs.set(adjacent, proof);
      return;
    }
    adjacent.remove(); // badge de otro usuario (nodo reutilizado por React)
  } else if (mode !== 'below') {
    const scope = (target.parentElement && target.parentElement.parentElement) || target.parentElement;
    if (scope && hasBadgeFor(scope, username)) return; // ya hay uno cerca (p. ej. nombre + @handle)
  }

  const badge = document.createElement('span');
  badge.className = BADGE_CLASS;
  badge.dataset.user = username;
  badge.dataset.mode = mode;
  paint(badge, entry);
  badgeTargets.set(badge, target);
  badgeProofs.set(badge, proof);
  if (hosted) target.appendChild(badge);
  else target.insertAdjacentElement('afterend', badge);
}

// Verifica que cada badge siga junto al usuario correcto; si no, lo quita.
function reconcileBadges() {
  for (const badge of document.querySelectorAll('.' + BADGE_CLASS)) {
    const target = badgeTargets.get(badge);
    const proof = badgeProofs.get(badge);
    const user = badge.dataset.user;
    const entry = peek(user);
    const placed = target && (badge.dataset.mode === 'after'
      ? badge.previousElementSibling === target
      : badge.parentElement === target);
    const valid =
      placed && proof &&
      target.isConnected &&
      proof.isConnected &&
      entry && entry.state === 'ok' &&
      userOfProof(proof) === user;

    if (!valid) { badge.remove(); continue; }
    if (badge.dataset.mode === 'below') {
      const col = avatarColumn(proof);
      if (!col || col.parentElement !== target) { badge.remove(); continue; }
      positionBelow(badge, col, target);
    }
    paint(badge, entry);
  }
}

function removeAllBadges() {
  document.querySelectorAll('.' + BADGE_CLASS).forEach((b) => b.remove());
}

/* ----------------------------------------------------------------------
 * Escaneo
 * -------------------------------------------------------------------- */
function processLink(link) {
  const username = usernameFromLink(link);
  if (!username || username === myUsername) return;

  lastSeen.set(username, Date.now());
  const entry = request(username, link);
  if (!entry || entry.state !== 'ok') return;

  const target = pickBadgeTarget(link, username);
  if (target) placeBadge(target, username, entry, link);
}

function processIdElement(el) {
  const id = Number(el.getAttribute(CONFIG.ID_ATTRIBUTE));
  if (!Number.isInteger(id)) return;

  const username = idToUsername.get(id);
  if (!username) { wantId(id); return; }
  if (username === myUsername) return;

  lastSeen.set(username, Date.now());
  const entry = request(username, el);
  if (!entry || entry.state !== 'ok') return;

  const target = findNameLeaf(el);
  if (target) placeBadge(target, username, entry, el);
}

// ¿Este contenedor solo menciona (por enlace o handle) a `username`?
function isExclusive(container, username) {
  for (const a of container.querySelectorAll(LINK_SELECTOR)) {
    const u = usernameFromLink(a);
    if (u && u !== username) return false;
  }
  const hs = new Set();
  collectHandles(container, hs);
  for (const h of hs) {
    const u = usernameFromHandleText(h);
    if (u && u !== username) return false;
  }
  return true;
}

// Busca el nombre visible que precede al handle: primero entre sus hermanos y,
// si no hay, entre los hermanos de su padre. Solo se acepta si el contenedor
// común pertenece únicamente a este usuario (si no, podría ser el de otra fila).
function nameLeafBeforeHandle(handle, username) {
  let el = handle;
  for (let level = 0; level < 2 && el && el.parentElement && el !== document.body; level++) {
    const container = el.parentElement;
    for (let sib = el.previousElementSibling; sib; sib = sib.previousElementSibling) {
      if (sib.classList.contains(BADGE_CLASS)) continue;
      const leaf = sib.children.length === 0
        ? (isNameText(sib.textContent.trim()) ? sib : null)
        : findNameLeaf(sib);
      if (leaf) return isExclusive(container, username) ? leaf : null;
    }
    el = container;
  }
  return null;
}

// Elemento cuyo texto completo es "@username" (sin enlace)
function processHandle(el) {
  const username = usernameFromHandleText(el);
  if (!username || username === myUsername) return null;

  lastSeen.set(username, Date.now());
  const entry = request(username, el);
  if (!entry || entry.state !== 'ok') return username;

  const target = nameLeafBeforeHandle(el, username) || el;
  placeBadge(target, username, entry, el);
  return username;
}

// Plan B para la página de perfil: si no se encontró el handle en pantalla,
// la URL da la identidad y el badge va junto al primer título "de contenido".
function processProfileRoute(handleUsers) {
  const username = usernameFromLocation();
  if (!username || username === myUsername || handleUsers.has(username)) return;

  lastSeen.set(username, Date.now());
  const entry = request(username);
  if (!entry || entry.state !== 'ok') return;

  for (const h of document.querySelectorAll('h1, h2')) {
    if (h.closest('nav, header, footer, aside, [role="dialog"], .' + BADGE_CLASS)) continue;
    const target = h.children.length === 0
      ? (isNameText(h.textContent.trim()) ? h : null)
      : findNameLeaf(h);
    if (target) { placeBadge(target, username, entry, ROUTE_PROOF); return; }
  }
  log(`perfil /@${username}: no se encontró dónde colocar el badge`);
}

/* ----------------------------------------------------------------------
 * Ancla por avatar: para listas sin enlace ni handle (p. ej. participantes
 * del chat). La URL del <img> se compara con las URLs de avatar que llegaron
 * en respuestas de la API junto al username. Si una URL pertenece a más de un
 * usuario (avatar por defecto), se descarta por ambigua.
 * -------------------------------------------------------------------- */
function avatarKey(raw) {
  if (!raw || typeof raw !== 'string') return null;
  let key = avatarKeyCache.get(raw);
  if (key !== undefined) return key;
  try {
    const u = new URL(raw, location.href);
    // el mismo archivo existe en varios tamaños/formatos: "…_hash-150w.jpeg", "…_hash-300w.webp"
    key = u.origin + u.pathname.replace(/(-\d+w)?\.[a-z0-9]{2,5}$/i, '');
  } catch (e) {
    key = null;
  }
  if (avatarKeyCache.size > 20000) avatarKeyCache.clear();
  avatarKeyCache.set(raw, key);
  return key;
}

// Devuelve true si aprendió algo nuevo. Una misma imagen puede pertenecer a varios
// usuarios (avatar por defecto, cuentas de una misma persona): se guardan todos.
function learnAvatar(raw, username) {
  const key = avatarKey(raw);
  if (!key) return false;
  let set = avatarToUser.get(key);
  if (!set) {
    if (avatarToUser.size > 20000) avatarToUser.clear();
    set = new Set();
    avatarToUser.set(key, set);
  }
  if (set.has(username) || set.size >= 2000) return false;
  set.add(username);
  return true;
}

// URL real de una imagen: ignora los marcadores de posición data: de carga diferida.
function imgSrc(img) {
  const ok = (v) => v && !v.startsWith('data:');
  if (ok(img.currentSrc)) return img.currentSrc;
  const src = img.getAttribute('src');
  if (ok(src)) return src;
  for (const attr of ['data-src', 'data-original', 'data-lazy-src']) {
    const v = img.getAttribute(attr);
    if (ok(v)) return v;
  }
  const srcset = img.getAttribute('srcset');
  if (srcset) {
    const first = srcset.trim().split(/\s+/)[0];
    if (ok(first)) return first;
  }
  return src || '';
}

// Los archivos de avatar empiezan con el id (24 hex) de su dueño:
//   …/users/avatars/5faea8fa8e1bf822bb1ad65d_ToBWE_BLv-150w.jpeg
function ownerHexOf(raw) {
  const m = /\/avatars\/([0-9a-f]{24})_/i.exec(String(raw || ''));
  return m ? m[1].toLowerCase() : null;
}

// Solo se usa ese prefijo como identidad si los datos de la API lo confirman
// (en casi todos los avatares aprendidos, el prefijo es el fullId del usuario).
function ownerTrusted() {
  return ownerStats.agree >= 15 && ownerStats.disagree <= ownerStats.agree * 0.02;
}

function usersForAvatar(img) {
  const raw = imgSrc(img);
  if (ownerTrusted()) {
    const hex = ownerHexOf(raw);
    const owner = hex && fullIdToUsername.get(hex);
    if (owner) return [owner];
  }
  const key = avatarKey(raw);
  const set = key && avatarToUser.get(key);
  return set ? [...set] : [];
}

// Usuario de una imagen: el único dueño, o el que se eligió por el nombre de su fila.
function userForAvatar(img) {
  const c = usersForAvatar(img);
  if (c.length === 0) return null;
  if (c.length === 1) return c[0];
  const chosen = avatarChoice.get(img);
  return chosen && c.includes(chosen) ? chosen : null;
}

// Imagen compartida: se elige el usuario cuyo nombre coincide EXACTAMENTE (sin
// símbolos ni emojis) con un texto de su fila, y solo si es uno solo.
function pickByRowName(img, candidates) {
  const wanted = new Map(); // nombre normalizado -> usernames
  for (const u of candidates) {
    for (const n of [displayNames.get(u), u]) {
      const k = n && normName(n);
      if (!k) continue;
      if (!wanted.has(k)) wanted.set(k, new Set());
      wanted.get(k).add(u);
    }
  }
  let el = img.parentElement;
  for (let i = 0; i < 4 && el && el !== document.body; i++) {
    if (el.querySelector(LINK_SELECTOR)) return null;
    for (const leaf of el.querySelectorAll('*')) {
      if (!isTextLeaf(leaf) || leaf.closest('.' + BADGE_CLASS)) continue;
      const text = ownText(leaf).trim();
      if (!isNameText(text)) continue;
      const hit = wanted.get(normName(text));
      if (hit && hit.size === 1) return hit.values().next().value;
    }
    el = el.parentElement;
  }
  return null;
}

// El contenedor no debe tener enlaces/handles propios (ahí mandan esas reglas)
// ni avatares de otros usuarios (sería ambiguo).
function isAvatarExclusive(container, username) {
  if (container.querySelector(LINK_SELECTOR)) return false;
  const hs = new Set();
  collectHandles(container, hs);
  if (hs.size > 0) return false;
  for (const im of container.querySelectorAll('img')) {
    const u = userForAvatar(im);
    if (u && u !== username) return false;
  }
  return true;
}

const TIME_RE = /^\d{1,2}:\d{2}(?:\s?[AaPp]\.?\s?[Mm]\.?)?$/;

// Una fila con hora ("2:52 PM") es un mensaje de chat, no un ítem de lista.
function hasTimeLeaf(container) {
  for (const el of container.querySelectorAll('*')) {
    if (isTextLeaf(el) && TIME_RE.test(ownText(el).trim())) return true;
  }
  return false;
}

// Columna del avatar: sube mientras sea hijo único, así queda como hermana de la burbuja.
function avatarColumn(img) {
  let col = img;
  for (let i = 0; i < 3 && col.parentElement && col.parentElement.children.length === 1; i++) {
    col = col.parentElement;
  }
  return col === img ? null : col;
}

// El badge se cuelga de la FILA (no del avatar, que puede recortar su contenido)
// y se coloca en absoluto justo debajo del avatar, centrado.
function positionBelow(badge, col, row) {
  const c = col.getBoundingClientRect();
  const r = row.getBoundingClientRect();
  badge.style.left = `${Math.round(c.left - r.left + c.width / 2)}px`;
  badge.style.top = `${Math.round(c.bottom - r.top + 2)}px`;
}

function placeBelowAvatar(img, username, entry) {
  const col = avatarColumn(img);
  const row = col && col.parentElement;
  if (!row) return;

  let badge = [...row.children].find(
    (c) => c.classList.contains(BADGE_CLASS) && c.dataset.mode === 'below'
  );
  if (badge && badge.dataset.user !== username) { badge.remove(); badge = null; }

  if (!badge) {
    if (getComputedStyle(row).position === 'static') row.style.position = 'relative';
    badge = document.createElement('span');
    badge.className = BADGE_CLASS;
    badge.dataset.user = username;
    badge.dataset.mode = 'below';
    badgeTargets.set(badge, row);
    badgeProofs.set(badge, img);
    row.appendChild(badge);
  }
  paint(badge, entry);
  positionBelow(badge, col, row);
}

function placeAvatarBadge(img, username, entry) {
  let el = img.parentElement;
  for (let i = 0; i < 4 && el && el !== document.body; i++) {
    if (!isAvatarExclusive(el, username)) return;
    if (hasTimeLeaf(el)) { placeBelowAvatar(img, username, entry); return; } // mensaje de chat
    const leaf = findNameLeaf(el, (t) => nameCompatible(username, t));
    if (leaf) { placeBadge(leaf, username, entry, img); return; }            // ítem de lista
    el = el.parentElement;
  }
}

const avatarStats = { matched: 0, unmatched: 0, sample: null, last: '' };

function processAvatar(img) {
  const candidates = usersForAvatar(img);
  if (candidates.length === 0) {
    avatarStats.unmatched++;
    if (!avatarStats.sample && img.width > 0 && img.width <= 64) avatarStats.sample = String(imgSrc(img) || img.src).slice(0, 120);
    return;
  }

  // Evita rehacer el trabajo pesado de ubicación para la misma imagen en cada escaneo.
  const src = imgSrc(img);
  const prev = avatarSeen.get(img);
  if (prev && prev.src === src && Date.now() - prev.t < 3000) {
    if (prev.user) { avatarStats.matched++; lastSeen.set(prev.user, Date.now()); request(prev.user, img); }
    return;
  }

  let username = candidates.length === 1 ? candidates[0] : pickByRowName(img, candidates);
  if (candidates.length > 1) {
    if (username) avatarChoice.set(img, username); else avatarChoice.delete(img);
  }
  if (!username) {
    avatarStats.unmatched++;
    avatarSeen.set(img, { src, user: null, t: Date.now() });
    return;
  }
  avatarStats.matched++;
  avatarSeen.set(img, { src, user: username, t: Date.now() });
  if (username === myUsername) return;
  if (img.closest(LINK_SELECTOR)) return; // ya lo cubre la regla de enlaces

  lastSeen.set(username, Date.now());
  const entry = request(username, img);
  if (!entry || entry.state !== 'ok') { avatarSeen.delete(img); return; }

  placeAvatarBadge(img, username, entry);
}

function logAvatarStats() {
  if (!lastScan) return;
  const line = JSON.stringify(lastScan);
  if (line === avatarStats.last) return;
  avatarStats.last = line;
  log('escaneo:', lastScan, '| diccionario avatares:', avatarToUser.size, '| vínculos:', bindings.size,
    '| ejemplo del diccionario:', avatarToUser.keys().next().value);
}

function collectImgs(root, out) {
  if (!root || root.nodeType !== 1 || !root.isConnected) return;
  if (root.tagName === 'IMG') out.add(root);
  root.querySelectorAll('img').forEach((i) => out.add(i));
}

/* ----------------------------------------------------------------------
 * Filas vinculadas por URL (temas, chats, conversaciones)
 *
 * La API devuelve cada tema / chat con su `slug` o id y con los usuarios que
 * menciona (autor, último respondedor, participantes). La página enlaza esa
 * fila por la misma URL. Eso ata la fila a un conjunto CERRADO de candidatos:
 * ahí sí se usa el nombre visible, pero solo para elegir entre esos pocos y
 * ubicar el badge. Si el texto coincide con más de uno, no se pone nada.
 * -------------------------------------------------------------------- */
function learnBinding(b) {
  if (!b || typeof b.key !== 'string' || b.key.length > 200 || !Array.isArray(b.users)) return false;
  let changed = false;
  let rec = bindings.get(b.key);
  if (!rec) {
    if (bindings.size > 20000) bindings.clear();
    rec = { users: new Map(), ids: new Set() };
    bindings.set(b.key, rec);
  }
  for (const u of b.users.slice(0, 30)) {
    if (!u || !isValidUsername(u.username)) continue;
    const display = typeof u.displayname === 'string' ? u.displayname : null;
    if (!rec.users.has(u.username) || rec.users.get(u.username) !== display) {
      rec.users.set(u.username, display);
      changed = true;
    }
  }
  if (Array.isArray(b.ids)) {
    for (const id of b.ids.slice(0, 30)) {
      if (Number.isInteger(id) && !rec.ids.has(id)) { rec.ids.add(id); changed = true; }
    }
  }
  return changed;
}

// Candidatos de una fila: los usuarios que venían en el objeto más los que se
// conocen por id (la página los resuelve por separado con GET /users?ids=).
function candidatesFor(key) {
  const rec = bindings.get(key);
  if (!rec) return null;
  const out = new Map(rec.users);
  for (const id of rec.ids) {
    const u = idToUsername.get(id);
    if (u && !out.has(u)) out.set(u, displayNames.get(u) || null);
  }
  return out;
}

// Último segmento de la ruta de un enlace del sitio (con caché).
function lastSegmentOf(href) {
  if (!href) return null;
  let last = hrefSegCache.get(href);
  if (last === undefined) {
    last = null;
    try {
      const u = new URL(href, location.origin);
      if (u.origin === location.origin) {
        const segs = u.pathname.split('/').filter(Boolean);
        if (segs.length) last = decodeURIComponent(segs[segs.length - 1]);
      }
    } catch (e) { /* href inválido */ }
    if (hrefSegCache.size > 20000) hrefSegCache.clear();
    hrefSegCache.set(href, last);
  }
  return last;
}

// Clave de la fila = último segmento de la URL del enlace (si es conocido).
function bindingKeyOf(a) {
  if (bindings.size === 0) return null;
  const last = lastSegmentOf(a.getAttribute('href'));
  return last && bindings.has(last) ? last : null;
}

/* ----------------------------------------------------------------------
 * Conversaciones privadas: GET /chat/messengers devuelve, por conversación,
 * su id y a sus participantes (userId y, normalmente, el usuario completo).
 * -------------------------------------------------------------------- */
let messengersFetchedAt = 0;
let messengersFetches = 0;

function fromMessengers(list) {
  const users = [];
  const binds = [];
  for (const m of list) {
    if (!m || typeof m.id !== 'string' || !Array.isArray(m.participants)) continue;
    const bu = [];
    const ids = [];
    for (const p of m.participants) {
      if (!p) continue;
      if (Number.isInteger(p.userId)) ids.push(p.userId);
      const u = p.user;
      if (u && typeof u.username === 'string') {
        const avatars = [];
        collectAvatarUrls(u.avatar, avatars, 0);
        users.push({
          id: Number.isInteger(u.id) ? u.id : null,
          fullId: typeof u.fullId === 'string' ? u.fullId : null,
          username: u.username,
          displayname: typeof u.displayname === 'string' ? u.displayname : null,
          avatars
        });
        bu.push({ username: u.username, displayname: typeof u.displayname === 'string' ? u.displayname : null });
      }
    }
    binds.push({ key: m.id, users: bu, ids });
  }
  return { users, bindings: binds };
}

async function fetchMessengers() {
  const myEpoch = epoch;
  messengersFetches++;
  try {
    const res = await fetch(`${API_BASE}/chat/messengers`, {
      headers: authHeaders(),
      ...(typeof AbortSignal !== 'undefined' && AbortSignal.timeout ? { signal: AbortSignal.timeout(20000) } : {})
    });
    if (res.status === 429) {
      pausedUntil = Math.max(pausedUntil, Date.now() + backoffMs);
      messengersFetchedAt = Date.now() - 100000; // reintentar en ~20 s
      return;
    }
    if (!res.ok) return;
    const list = await res.json();
    if (myEpoch !== epoch || !Array.isArray(list)) return;
    ingest(fromMessengers(list), 'api');
  } catch (e) {
    log('No se pudo pedir las conversaciones:', e);
  }
}

// Si hay filas de conversación en pantalla que no conocemos, las pedimos (máx. 1 vez cada 2 min).
function ensureMessengers() {
  if (!CONFIG.FETCH_MESSENGERS || Date.now() - messengersFetchedAt < 120000) return;
  for (const a of document.querySelectorAll('a[href*="/chat/messengers/"]')) {
    const key = lastSegmentOf(a.getAttribute('href'));
    if (key && /^[0-9a-f]{24}$/i.test(key) && !bindings.has(key)) {
      messengersFetchedAt = Date.now();
      fetchMessengers();
      return;
    }
  }
}

const nameRegexCache = new Map();
function nameRegex(name) {
  let re = nameRegexCache.get(name);
  if (!re) {
    const esc = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    re = new RegExp('^(?:Por\\s+)?' + esc + '(?=$|[\\s•·,:])');
    nameRegexCache.set(name, re);
  }
  return re;
}

// Elige, entre los candidatos, el que nombra este texto. Gana el nombre más
// largo; si dos usuarios distintos empatan, es ambiguo y devuelve null.
function matchName(text, candidates) {
  const t = (text || '').trim();
  if (!t || t.length > 200) return null;
  let best = null;
  let bestLen = 0;
  let tie = false;
  for (const [username, display] of candidates) {
    if (username === myUsername) continue;
    for (const name of [display, username]) {
      if (!name || name.length < 2) continue;
      // coincide el texto tal cual ("Por Ana ...") o, sin símbolos ni emojis, el nombre entero
      if (!nameRegex(name).test(t) && normName(t) !== normName(name)) continue;
      if (name.length > bestLen) { best = username; bestLen = name.length; tie = false; }
      else if (name.length === bestLen && best !== username) tie = true;
      break;
    }
  }
  return tie ? null : best;
}

// ¿Este contenedor solo contiene enlaces de la fila `key` (o ajenos al sistema)?
function ownsOnlyKey(container, key) {
  for (const a of container.querySelectorAll('a[href]')) {
    const k = bindingKeyOf(a);
    if (k && k !== key) return false;
  }
  return true;
}

function findBoundLeaf(anchor, key, candidates) {
  let scope = anchor;
  for (let i = 0; i < 4 && scope && scope !== document.body; i++) {
    if (i > 0 && !ownsOnlyKey(scope, key)) return null;
    for (const el of scope.querySelectorAll('*')) {
      if (!isTextLeaf(el) || el.closest('.' + BADGE_CLASS)) continue;
      const username = matchName(ownText(el), candidates);
      if (username) return { leaf: el, username };
    }
    scope = scope.parentElement;
  }
  return null;
}

function userOfBoundLeaf(leaf) {
  const rec = boundProofs.get(leaf);
  if (!rec || !rec.anchor.isConnected || bindingKeyOf(rec.anchor) !== rec.key) return null;
  const candidates = candidatesFor(rec.key);
  return candidates ? matchName(ownText(leaf), candidates) : null;
}

function isBlockLike(el) {
  const d = getComputedStyle(el).display;
  return !(d === 'inline' || d.startsWith('inline'));
}

const boundStats = { anchors: 0, rows: 0 };

function processBound(anchor) {
  const key = bindingKeyOf(anchor);
  if (!key) return;
  boundStats.anchors++;

  // Participantes que el chat menciona solo por id: se piden en lote (GET /users?ids=).
  for (const id of bindings.get(key).ids) {
    if (!idToUsername.has(id)) wantId(id);
  }

  const found = findBoundLeaf(anchor, key, candidatesFor(key));
  if (!found) return;
  boundStats.rows++;

  const { leaf, username } = found;
  lastSeen.set(username, Date.now());
  const entry = request(username, anchor);
  if (!entry || entry.state !== 'ok') return;

  boundProofs.set(leaf, { anchor, key });
  placeBadge(leaf, username, entry, leaf, isBlockLike(leaf) ? 'in' : 'after');
}

function collectAnchors(root, out) {
  if (!root || root.nodeType !== 1 || !root.isConnected) return;
  if (root.matches('a[href]')) out.add(root);
  const parent = root.closest('a[href]');
  if (parent) out.add(parent);
  root.querySelectorAll('a[href]').forEach((a) => out.add(a));
}

const HANDLE_SKIP_TAGS = new Set(['A', 'TEXTAREA', 'SCRIPT', 'STYLE', 'NOSCRIPT']);

function collectHandles(root, out) {
  if (!root || root.nodeType !== 1 || !root.isConnected) return;

  const matches = (el) => el.children.length <= 3 && HANDLE_TEXT_RE.test(el.textContent);
  const deepest = (el) => ![...el.children].some((c) => HANDLE_TEXT_RE.test(c.textContent));

  if (matches(root) && deepest(root) && !root.closest('a, textarea, [contenteditable], .' + BADGE_CLASS)) {
    out.add(root);
  }

  const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, {
    acceptNode: (el) => {
      if (HANDLE_SKIP_TAGS.has(el.tagName) || el.isContentEditable || el.classList.contains(BADGE_CLASS)) {
        return NodeFilter.FILTER_REJECT; // descarta el subárbol
      }
      return matches(el) && deepest(el) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    }
  });
  for (let el = walker.nextNode(); el; el = walker.nextNode()) out.add(el);
}

function collectLinks(root, out) {
  if (!root || root.nodeType !== 1 || !root.isConnected) return;
  if (root.matches(LINK_SELECTOR)) out.add(root);
  const parentLink = root.closest(LINK_SELECTOR);
  if (parentLink) out.add(parentLink);
  root.querySelectorAll(LINK_SELECTOR).forEach((l) => out.add(l));
  const card = root.closest(CARD_SELECTOR);
  if (card) card.querySelectorAll(LINK_SELECTOR).forEach((l) => out.add(l));
}

const dirty = new Set();
let wantFull = false;
let flushTimer = null;

function scheduleFlush(full = false) {
  if (full) wantFull = true;
  if (!flushTimer) flushTimer = setTimeout(flush, CONFIG.FLUSH_DEBOUNCE_MS);
}

// pending debería ser exactamente (cola + lote en vuelo). Si sobra algo, se libera.
function healPending() {
  if (pending.size === 0) return;
  const live = new Set(queue);
  inFlight.forEach((u) => live.add(u));
  for (const u of [...pending]) {
    if (!live.has(u)) { pending.delete(u); retries.delete(u); healed++; }
  }
}

let lastScan = null;

function flush() {
  flushTimer = null;
  const full = wantFull;
  const wantFullNow = full;
  wantFull = false;
  const roots = [...dirty];
  dirty.clear();
  if (!ready) return;

  try {
    reconcileBadges();
    if (wantFullNow) { healPending(); ensureMessengers(); }

    const links = new Set();
    const handles = new Set();
    const imgs = new Set();
    const anchors = new Set();
    if (full) {
      document.querySelectorAll(LINK_SELECTOR).forEach((l) => links.add(l));
      collectHandles(document.body || document.documentElement, handles);
      collectImgs(document.body || document.documentElement, imgs);
      if (bindings.size > 0) document.querySelectorAll('a[href]').forEach((a) => anchors.add(a));
    } else {
      roots.forEach((r) => {
        collectLinks(r, links); collectHandles(r, handles); collectImgs(r, imgs);
        if (bindings.size > 0) collectAnchors(r, anchors);
      });
    }
    if (full) {
      avatarStats.matched = 0; avatarStats.unmatched = 0; avatarStats.sample = null;
      boundStats.anchors = 0; boundStats.rows = 0;
    }
    const handleUsers = new Set();
    handles.forEach((h) => { const u = processHandle(h); if (u) handleUsers.add(u); });
    links.forEach(processLink);
    imgs.forEach(processAvatar);
    anchors.forEach(processBound);
    if (full) processProfileRoute(handleUsers);
    if (full) {
      lastScan = {
        enlaces: links.size, handles: handles.size, imagenes: imgs.size,
        imagenesConUsuario: avatarStats.matched, imagenesSinUsuario: avatarStats.unmatched,
        ejemploImagenSinUsuario: avatarStats.sample,
        enlacesConClave: boundStats.anchors, filasResueltas: boundStats.rows
      };
      if (DEBUG) logAvatarStats();
    }

    if (full && ID_SELECTOR) document.querySelectorAll(ID_SELECTOR).forEach(processIdElement);

    if (full && lastSeen.size > 3000) {
      const cutoff = Date.now() - 5 * 60 * 1000;
      for (const [u, t] of lastSeen) if (t < cutoff) lastSeen.delete(u);
    }
  } catch (e) {
    console.error('[Mazmo Match] Error al escanear:', e);
  }
}

function isOwnNode(node) {
  const el = node.nodeType === 1 ? node : node.parentElement;
  return !!(el && el.closest && el.closest('.' + BADGE_CLASS));
}

let observerAttached = false;
function attachObserver() {
  if (observerAttached) return;
  observerAttached = true;

  const observer = new MutationObserver((mutations) => {
    let any = false;
    for (const m of mutations) {
      if (m.type === 'attributes') {
        // React reutilizó un <a> cambiándole el href
        if (!isOwnNode(m.target)) { dirty.add(m.target); any = true; }
        continue;
      }
      for (const n of m.addedNodes) {
        if (n.nodeType === 1 && !isOwnNode(n)) { dirty.add(n); any = true; }
      }
    }
    if (any) scheduleFlush();
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['href']
  });
}

/* ----------------------------------------------------------------------
 * Arranque y sesión
 * -------------------------------------------------------------------- */
async function loadMyData() {
  try {
    const meRes = await fetch(`${API_BASE}/users/me`, { headers: authHeaders() });
    if (!meRes.ok) return { status: 'retry' };
    const me = await meRes.json();
    if (!me || !isValidUsername(me.username)) return { status: 'retry' };

    const chkRes = await fetch(`${API_BASE}/users/${encodeURIComponent(me.username)}/checklist`, {
      headers: authHeaders()
    });
    if (chkRes.status === 404) return { status: 'stop' };
    if (!chkRes.ok) return { status: 'retry' };

    const selections = flattenChecklist(await chkRes.json());
    if (selections.size === 0) return { status: 'stop' };
    return { status: 'ok', username: me.username, selections };
  } catch (e) {
    return { status: 'retry' };
  }
}

async function start() {
  const myEpoch = ++epoch;

  // Reinicio limpio (también al cambiar de cuenta)
  ready = false;
  workerRunning = false;
  queue = [];
  pending.clear();
  retries.clear();
  lastSeen.clear();
  cache.clear();
  myUsername = null;
  mySelections = null;
  ownerKey = null;
  pausedUntil = 0;
  backoffMs = CONFIG.BACKOFF_START_MS;
  removeAllBadges();

  for (let attempt = 0; myEpoch === epoch; attempt++) {
    activeToken = getToken();
    if (!activeToken) { await sleep(2000); continue; }

    const r = await loadMyData();
    if (myEpoch !== epoch) return;

    if (r.status === 'stop') {
      log('Sin checklist propio: nada que comparar.');
      return;
    }
    if (r.status === 'retry') {
      await sleep(Math.min(30000, 2000 * 2 ** Math.min(attempt, 4)));
      continue;
    }

    myUsername = r.username;
    mySelections = r.selections;
    ownerKey = `${myUsername}:${hashSelections(mySelections)}`;

    await loadStoredCache();
    if (myEpoch !== epoch) return;

    ready = true;
    attachObserver();
    scheduleFlush(true);
    return;
  }
}

start();

// Detecta login/logout/cambio de cuenta
setInterval(() => {
  if (getToken() !== activeToken) start();
}, 5000);

// Red de seguridad: escaneo completo periódico
setInterval(() => {
  if (ready && !document.hidden) scheduleFlush(true);
}, CONFIG.FULL_SCAN_EVERY_MS);

// Si en 30 s no llegó ningún dato de red, las reglas por avatar y por URL no
// pueden funcionar: avisarlo (aunque no esté el modo debug).
setTimeout(() => {
  if (feedStats.page + feedStats.background === 0) {
    console.warn('[Mazmo Match] No llegó ningún dato de red (ni de la página ni del segundo plano).');
  }
}, 30000);

/* ----------------------------------------------------------------------
 * Opciones del usuario (se cambian desde la ventana del ícono)
 * -------------------------------------------------------------------- */
try {
  Promise.resolve(ext.storage.local.get('fetchMessengers')).then((v) => {
    CONFIG.FETCH_MESSENGERS = !!v && v.fetchMessengers === true;
    if (CONFIG.FETCH_MESSENGERS) scheduleFlush(true);
  }).catch(() => {});
  ext.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.fetchMessengers) return;
    CONFIG.FETCH_MESSENGERS = changes.fetchMessengers.newValue === true;
    if (CONFIG.FETCH_MESSENGERS) scheduleFlush(true);
  });
} catch (e) {
  log('No se pudieron leer las opciones:', e);
}

/* ----------------------------------------------------------------------
 * Diagnóstico (SOLO en modo debug): en la consola de mazmo.net, ejecutá
 *     localStorage.mazmoMatchDebug = '1'      (y recargá la página)
 *     document.documentElement.dataset.mazmoMatch
 * Se escribe en un atributo de <html>, que puede leer cualquier script de la página:
 * por eso no se activa salvo que lo pidas, y conviene desactivarlo al terminar
 * (localStorage.removeItem('mazmoMatchDebug')).
 * -------------------------------------------------------------------- */
function publishDiagnostics() {
  try {
    let ok = 0, none = 0, error = 0;
    for (const e of cache.values()) {
      if (e.state === 'ok') ok++; else if (e.state === 'none') none++; else error++;
    }
    document.documentElement.dataset.mazmoMatch = JSON.stringify({
      version: ext.runtime.getManifest().version,
      listo: ready,
      yo: myUsername,
      ruta: location.pathname,
      datosDeRed: feedStats,
      diccionario: { avatares: avatarToUser.size, ids: idToUsername.size, vinculos: bindings.size, fullIds: fullIdToUsername.size },
      duenoDelAvatar: { coinciden: ownerStats.agree, difieren: ownerStats.disagree, confiable: ownerTrusted() },
      cache: { ok, none, error },
      cola: queue.length,
      enVuelo: pending.size,
      enLote: inFlight.size,
      liberados: healed,
      conversacionesPedidas: messengersFetches,
      ultimoError: lastError,
      ultimosSinChecklist: noneLog.slice(-25),
      segundoPlano: bgStats,
      pausaMs: Math.max(0, pausedUntil - Date.now()),
      resultadosHTTP: outcomeCounts,
      badgesEnPantalla: document.querySelectorAll('.' + BADGE_CLASS).length,
      ultimoEscaneo: lastScan
    });
  } catch (e) { /* nunca romper la página */ }
}
if (DEBUG) {
  setInterval(publishDiagnostics, 2000);
  console.info('[Mazmo Match] modo debug activo. Diagnóstico: document.documentElement.dataset.mazmoMatch');
}

/* ----------------------------------------------------------------------
 * "¿Por qué esta fila no tiene badge?"  Solo en modo debug. En la consola de mazmo.net:
 *     localStorage.mazmoMatchDebug = '1'      (y recargá la página)
 *     document.documentElement.dataset.mazmoExplain = 'NombreVisible'
 * (esperá 1 segundo) y luego
 *     document.documentElement.dataset.mazmoExplainResult
 * Para repetir con el mismo nombre, cambiá antes el valor (p. ej. 'NombreVisible ').
 * -------------------------------------------------------------------- */
const shortUrl = (u) => String(u || '').slice(0, 100);

function explainLeaf(el) {
  const texto = ownText(el).trim();
  const info = {
    etiqueta: el.tagName.toLowerCase(),
    texto,
    conInsignia: !!(el.nextElementSibling && el.nextElementSibling.classList.contains(BADGE_CLASS)) ||
      !!el.querySelector(':scope > .' + BADGE_CLASS),
    niveles: []
  };
  const a = el.closest('a[href]');
  if (a) {
    const key = bindingKeyOf(a);
    const cands = key ? candidatesFor(key) : null;
    info.enlace = {
      href: shortUrl(a.getAttribute('href')),
      claveConocida: !!key,
      candidatos: cands ? [...cands].slice(0, 8).map(([u, d]) => (d ? `${u} (${d})` : u)) : null,
      coincide: cands ? matchName(texto, cands) : null,
      idsSinResolver: key ? [...bindings.get(key).ids].filter((id) => !idToUsername.has(id)) : null
    };
  }
  let node = el.parentElement;
  for (let i = 1; i <= 5 && node && node !== document.body; i++, node = node.parentElement) {
    const hs = new Set();
    collectHandles(node, hs);
    info.niveles.push({
      nivel: i,
      etiqueta: node.tagName.toLowerCase(),
      enlacesPerfil: node.querySelectorAll(LINK_SELECTOR).length,
      handles: hs.size,
      conHora: hasTimeLeaf(node),
      imagenesConUsuario: [...node.querySelectorAll('img')]
        .map((im) => ({ src: shortUrl(imgSrc(im)), usuarios: usersForAvatar(im).slice(0, 4), elegido: userForAvatar(im) }))
        .filter((x) => x.usuarios.length)
        .slice(0, 3)
    });
  }
  return info;
}

function explainName(name) {
  const target = normName(name);
  const out = { nombre: name, usuarios: [], hojas: [] };

  const names = new Set();
  for (const [u, d] of displayNames) if (normName(u) === target || (d && normName(d) === target)) names.add(u);
  for (const u of cache.keys()) if (normName(u) === target) names.add(u);
  for (const u of [...names].slice(0, 5)) {
    const avatares = [];
    for (const [k, set] of avatarToUser) {
      if (set.has(u)) { avatares.push(shortUrl(k)); if (avatares.length >= 3) break; }
    }
    const ids = [];
    for (const [id, un] of idToUsername) if (un === u) ids.push(id);
    const e = cache.get(u);
    out.usuarios.push({
      username: u,
      displayname: displayNames.get(u) || null,
      ids,
      avatares,
      cache: e ? { estado: e.state, porcentaje: e.percentage ?? null, venceEnMin: Math.round((e.exp - Date.now()) / 60000) } : null,
      pendiente: pending.has(u),
      esYo: u === myUsername
    });
  }

  for (const el of document.querySelectorAll('body *')) {
    if (out.hojas.length >= 5) break;
    if (!isTextLeaf(el) || el.closest('.' + BADGE_CLASS)) continue;
    const text = ownText(el).trim();
    if (!text || text.length > 80 || normName(text) !== target) continue;
    out.hojas.push(explainLeaf(el));
  }
  return out;
}

let lastExplain = '';
if (DEBUG) {
  setInterval(() => {
    try {
      const q = document.documentElement.dataset.mazmoExplain || '';
      if (!q || q === lastExplain) return;
      lastExplain = q;
      document.documentElement.dataset.mazmoExplainResult = JSON.stringify(explainName(q));
    } catch (e) {
      document.documentElement.dataset.mazmoExplainResult = 'error: ' + String(e);
    }
  }, 1000);
}
